#ifndef GOERTZEL_H
#define GOERTZEL_H

float goertzel_mag(int numSamples,int TARGET_FREQUENCY,int SAMPLING_RATE, float* data);

#endif

